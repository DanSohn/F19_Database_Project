/*-------------------------------------
GET LISTS
*/-------------------------------------
--Get list of all clients
	Select *
	FROM	Client AS c;
	
--List of orders that are not complete and not in the gathering supplies state
    SELECT  o.OrderNumber, o.OrderStatus
	FROM    Order AS o
    WHERE   o.orderStatus <> "Complete"
    AND     o.orderStatus <> "Collected Supplies" ;

--List of Invoices (manager side)
	SELECT	*
	FROM	Invoice;
	
-- List of Invoices (client side)
	SELECT	*
	FROM	Invoice AS i
	WHERE	i.c_sin = $c_sin;
	
-- List of Installations not complete
	SELECT	*
	FROM	Installation AS i
	WHERE	i.orderStatus <> "Complete";
	
-- List of Orders that are ready for preparation
	SELECT	*
	FROM	Order AS o
	WHERE	o.orderStatus = "Artwork Complete";
	
-- 
/*-------------------------------------
MANAGERS ACTIONS
*/-------------------------------------

	
--Manager communicates with client
	SELECT	c.PhoneNumber, c.Email
	FROM	Client AS c
	WHERE	c.SIN = $c_sin;
	
--Manager creates Order (INSERT new order)
    INSERT INTO ORDER (OrderNumber, Cost, Quantity, C_SIN)
    VALUES (?,?,?, SELECT c.SIN
                        FROM CLIENT AS c, MANAGER AS m
                        WHERE m.SIN = c.M_SIN));

--ORDER SUPPLIES (Get list of supplies)
    $Size = $_POST['Size'];
    $Color = $_POST['Color'];
    $Type = $_POST['Type'];

    SELECT  supplier.*, supply.*
    FROM    SUPPLIER AS supplier, SUPPY AS supply
    WHERE   supply.Size = $Size
    AND     supply.Color = $Color
    AND     supply.Type = $Type
    AND     supply.SupplierName = supplier.Name;
    
-- Manager completes order/kickstarts invoice
	UPDATE	Order AS o
	SET		OrderStatus = "Complete"
	WHERE	o.OrderNumber = $orderNo
	
	$Cost = SELECT 	SUM(o.cost)
					FROM	Order as O
					WHERE 	o.c_sin IN
						   (SELECT 	c.SIN
							FROM		Client AS c
							WHERE		o.c-sin=c.sin))
	$OrderNumber = SELECT 	o.OrderNumber
					FROM	Order as O
					WHERE 	o.c_sin IN
						   (SELECT 	c.SIN
							FROM		Client AS c
							WHERE		o.c-sin=c.sin))
	
	INSERT INTO	Invoice (InvoiceNumber, Cost, Date, Status, C_SIN, OrderNumber)
	VALUES ($InvoiceNo, $Cost, $todaysDate, "Unpaid", $OrderNumber);
							
/*-------------------------------------
CLIENT ACTIONS
*/-------------------------------------

--Client Communicates with Manager (GET phone number)
    SELECT  m.FName, m.LName, m.PhoneNumber, m.Email
    FROM    MANAGER AS m;

--Client Requests Installation
	INSERT INTO INSTALLATION (SIN, Location, Substrate, OrderNo)
    VALUES ($c_sin, $location, $subtrate, 	SELECT c.SIN
											FROM CLIENT AS c, MANAGER AS m
											WHERE m.SIN = c.M_SIN));
    
--Client Settles Invoice (views currently) - After payment verified
    UPDATE	INVOICE AS i
	SET		status = "Paid."
	WHERE	i.c_sin = $c_sin
	AND		i.invoiceNumber = $invoiceNumber;

/*-------------------------------------
EMPLOYEE ACTIONS
*/-------------------------------------

--EMPLOYEE COLLECTS SUPPLY FROM SUPPLIER (Change order status to "In Progress")O.
    UPDATE  ORDER AS o
    SET     o.orderStatus = "Collected Supplies"
    WHERE   o.orderNumber = $orderNumber;
                                
--EMPLOYEE PREPARES ORDER
    UPDATE  ORDER AS o
    SET     o.OrderStatus = "In Preparation"
    WHERE   o.orderNubmer = $orderNumber;

-- EMPLOYEE COMPLETES INSTALLATION
	UPDATE	INSTALLATION AS i
	SET		i.Status = "Complete"
	WHERE	i.OrderNumber = $orderNumber

/*-------------------------------------
DESIGNER ACTIONS
*/-------------------------------------
                    
--DESIGNER CREATES ARTWORK
    UPDATE  ORDER AS o
    SET     o.orderArtStatus = "Completed"
    WHERE   o.OrderNumber = $orderNo;
    
    

                        






